﻿namespace UI.Vip
{
    partial class frmAddNewVip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbTelephone = new System.Windows.Forms.TextBox();
            this.tbCardNo = new System.Windows.Forms.TextBox();
            this.tbMobilephone = new System.Windows.Forms.TextBox();
            this.numTempTimes = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.numRemain = new System.Windows.Forms.NumericUpDown();
            this.numHowMach = new System.Windows.Forms.NumericUpDown();
            this.dataEnd = new System.Windows.Forms.DateTimePicker();
            this.dataBgn = new System.Windows.Forms.DateTimePicker();
            this.cbCardKind = new System.Windows.Forms.ComboBox();
            this.cbSex = new System.Windows.Forms.ComboBox();
            this.tbTips = new System.Windows.Forms.TextBox();
            this.lblTips = new System.Windows.Forms.Label();
            this.btnShoot = new System.Windows.Forms.Button();
            this.btnOpenVideo = new System.Windows.Forms.Button();
            this.pVideo = new System.Windows.Forms.Panel();
            this.lblRemain = new System.Windows.Forms.Label();
            this.lvlHowMach = new System.Windows.Forms.Label();
            this.lblCardKind = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblBgnTime = new System.Windows.Forms.Label();
            this.lblMPhone = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.tbNo2 = new System.Windows.Forms.TextBox();
            this.lvlNo2 = new System.Windows.Forms.Label();
            this.tbnational = new System.Windows.Forms.TextBox();
            this.lblNational = new System.Windows.Forms.Label();
            this.tbNationality = new System.Windows.Forms.TextBox();
            this.lblNationality = new System.Windows.Forms.Label();
            this.lblSex = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNo = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTempTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRemain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowMach)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbTelephone);
            this.groupBox1.Controls.Add(this.tbCardNo);
            this.groupBox1.Controls.Add(this.tbMobilephone);
            this.groupBox1.Controls.Add(this.numTempTimes);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.numRemain);
            this.groupBox1.Controls.Add(this.numHowMach);
            this.groupBox1.Controls.Add(this.dataEnd);
            this.groupBox1.Controls.Add(this.dataBgn);
            this.groupBox1.Controls.Add(this.cbCardKind);
            this.groupBox1.Controls.Add(this.cbSex);
            this.groupBox1.Controls.Add(this.tbTips);
            this.groupBox1.Controls.Add(this.lblTips);
            this.groupBox1.Controls.Add(this.btnShoot);
            this.groupBox1.Controls.Add(this.btnOpenVideo);
            this.groupBox1.Controls.Add(this.pVideo);
            this.groupBox1.Controls.Add(this.lblRemain);
            this.groupBox1.Controls.Add(this.lvlHowMach);
            this.groupBox1.Controls.Add(this.lblCardKind);
            this.groupBox1.Controls.Add(this.lblEndTime);
            this.groupBox1.Controls.Add(this.lblBgnTime);
            this.groupBox1.Controls.Add(this.lblMPhone);
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.tbNo2);
            this.groupBox1.Controls.Add(this.lvlNo2);
            this.groupBox1.Controls.Add(this.tbnational);
            this.groupBox1.Controls.Add(this.lblNational);
            this.groupBox1.Controls.Add(this.tbNationality);
            this.groupBox1.Controls.Add(this.lblNationality);
            this.groupBox1.Controls.Add(this.lblSex);
            this.groupBox1.Controls.Add(this.tbName);
            this.groupBox1.Controls.Add(this.lblName);
            this.groupBox1.Controls.Add(this.lblNo);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 315);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "会员信息资料";
            // 
            // tbTelephone
            // 
            this.tbTelephone.Location = new System.Drawing.Point(66, 99);
            this.tbTelephone.Name = "tbTelephone";
            this.tbTelephone.Size = new System.Drawing.Size(100, 21);
            this.tbTelephone.TabIndex = 48;
            // 
            // tbCardNo
            // 
            this.tbCardNo.Location = new System.Drawing.Point(66, 18);
            this.tbCardNo.Name = "tbCardNo";
            this.tbCardNo.Size = new System.Drawing.Size(100, 21);
            this.tbCardNo.TabIndex = 47;
            // 
            // tbMobilephone
            // 
            this.tbMobilephone.Location = new System.Drawing.Point(235, 99);
            this.tbMobilephone.Name = "tbMobilephone";
            this.tbMobilephone.Size = new System.Drawing.Size(100, 21);
            this.tbMobilephone.TabIndex = 46;
            // 
            // numTempTimes
            // 
            this.numTempTimes.Enabled = false;
            this.numTempTimes.Location = new System.Drawing.Point(236, 152);
            this.numTempTimes.Maximum = new decimal(new int[] {
            -62924560,
            804571906,
            542643,
            0});
            this.numTempTimes.Name = "numTempTimes";
            this.numTempTimes.Size = new System.Drawing.Size(100, 21);
            this.numTempTimes.TabIndex = 45;
            this.numTempTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(176, 156);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 44;
            this.label1.Text = "次卡次数";
            // 
            // numRemain
            // 
            this.numRemain.DecimalPlaces = 2;
            this.numRemain.Location = new System.Drawing.Point(66, 179);
            this.numRemain.Maximum = new decimal(new int[] {
            -1486618625,
            232830643,
            0,
            0});
            this.numRemain.Name = "numRemain";
            this.numRemain.Size = new System.Drawing.Size(100, 21);
            this.numRemain.TabIndex = 43;
            // 
            // numHowMach
            // 
            this.numHowMach.DecimalPlaces = 2;
            this.numHowMach.Location = new System.Drawing.Point(236, 179);
            this.numHowMach.Maximum = new decimal(new int[] {
            -62924560,
            804571906,
            542643,
            0});
            this.numHowMach.Name = "numHowMach";
            this.numHowMach.Size = new System.Drawing.Size(100, 21);
            this.numHowMach.TabIndex = 42;
            // 
            // dataEnd
            // 
            this.dataEnd.Location = new System.Drawing.Point(235, 126);
            this.dataEnd.Name = "dataEnd";
            this.dataEnd.Size = new System.Drawing.Size(100, 21);
            this.dataEnd.TabIndex = 38;
            // 
            // dataBgn
            // 
            this.dataBgn.Location = new System.Drawing.Point(66, 126);
            this.dataBgn.Name = "dataBgn";
            this.dataBgn.Size = new System.Drawing.Size(100, 21);
            this.dataBgn.TabIndex = 37;
            // 
            // cbCardKind
            // 
            this.cbCardKind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCardKind.FormattingEnabled = true;
            this.cbCardKind.Items.AddRange(new object[] {
            "次卡",
            "月卡",
            "季卡",
            "半年卡",
            "一年卡",
            "二年卡",
            "三年卡",
            "高温卡"});
            this.cbCardKind.Location = new System.Drawing.Point(66, 153);
            this.cbCardKind.Name = "cbCardKind";
            this.cbCardKind.Size = new System.Drawing.Size(100, 20);
            this.cbCardKind.TabIndex = 36;
            this.cbCardKind.SelectedIndexChanged += new System.EventHandler(this.cbCardKind_SelectedIndexChanged);
            // 
            // cbSex
            // 
            this.cbSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSex.FormattingEnabled = true;
            this.cbSex.Items.AddRange(new object[] {
            "女",
            "男",
            "其它"});
            this.cbSex.Location = new System.Drawing.Point(66, 45);
            this.cbSex.Name = "cbSex";
            this.cbSex.Size = new System.Drawing.Size(100, 20);
            this.cbSex.TabIndex = 34;
            // 
            // tbTips
            // 
            this.tbTips.Location = new System.Drawing.Point(7, 225);
            this.tbTips.Multiline = true;
            this.tbTips.Name = "tbTips";
            this.tbTips.Size = new System.Drawing.Size(546, 84);
            this.tbTips.TabIndex = 33;
            // 
            // lblTips
            // 
            this.lblTips.Location = new System.Drawing.Point(7, 210);
            this.lblTips.Name = "lblTips";
            this.lblTips.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblTips.Size = new System.Drawing.Size(53, 12);
            this.lblTips.TabIndex = 32;
            this.lblTips.Text = "备注信息";
            // 
            // btnShoot
            // 
            this.btnShoot.Location = new System.Drawing.Point(459, 177);
            this.btnShoot.Name = "btnShoot";
            this.btnShoot.Size = new System.Drawing.Size(95, 23);
            this.btnShoot.TabIndex = 30;
            this.btnShoot.Text = "拍照";
            this.btnShoot.UseVisualStyleBackColor = true;
            this.btnShoot.Click += new System.EventHandler(this.btnShoot_Click);
            // 
            // btnOpenVideo
            // 
            this.btnOpenVideo.Location = new System.Drawing.Point(342, 177);
            this.btnOpenVideo.Name = "btnOpenVideo";
            this.btnOpenVideo.Size = new System.Drawing.Size(95, 23);
            this.btnOpenVideo.TabIndex = 29;
            this.btnOpenVideo.Text = "开启摄像头";
            this.btnOpenVideo.UseVisualStyleBackColor = true;
            this.btnOpenVideo.Click += new System.EventHandler(this.btnOpenVideo_Click);
            // 
            // pVideo
            // 
            this.pVideo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pVideo.Location = new System.Drawing.Point(341, 18);
            this.pVideo.Name = "pVideo";
            this.pVideo.Size = new System.Drawing.Size(213, 156);
            this.pVideo.TabIndex = 28;
            // 
            // lblRemain
            // 
            this.lblRemain.Location = new System.Drawing.Point(7, 183);
            this.lblRemain.Name = "lblRemain";
            this.lblRemain.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblRemain.Size = new System.Drawing.Size(53, 12);
            this.lblRemain.TabIndex = 24;
            this.lblRemain.Text = "卡内金额";
            // 
            // lvlHowMach
            // 
            this.lvlHowMach.Location = new System.Drawing.Point(176, 183);
            this.lvlHowMach.Name = "lvlHowMach";
            this.lvlHowMach.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lvlHowMach.Size = new System.Drawing.Size(53, 12);
            this.lvlHowMach.TabIndex = 22;
            this.lvlHowMach.Text = "卡项金额";
            // 
            // lblCardKind
            // 
            this.lblCardKind.Location = new System.Drawing.Point(7, 156);
            this.lblCardKind.Name = "lblCardKind";
            this.lblCardKind.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCardKind.Size = new System.Drawing.Size(53, 12);
            this.lblCardKind.TabIndex = 20;
            this.lblCardKind.Text = "卡类型";
            // 
            // lblEndTime
            // 
            this.lblEndTime.Location = new System.Drawing.Point(176, 132);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEndTime.Size = new System.Drawing.Size(53, 12);
            this.lblEndTime.TabIndex = 18;
            this.lblEndTime.Text = "到期日期";
            // 
            // lblBgnTime
            // 
            this.lblBgnTime.Location = new System.Drawing.Point(7, 129);
            this.lblBgnTime.Name = "lblBgnTime";
            this.lblBgnTime.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblBgnTime.Size = new System.Drawing.Size(53, 12);
            this.lblBgnTime.TabIndex = 16;
            this.lblBgnTime.Text = "注册日期";
            // 
            // lblMPhone
            // 
            this.lblMPhone.Location = new System.Drawing.Point(176, 105);
            this.lblMPhone.Name = "lblMPhone";
            this.lblMPhone.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblMPhone.Size = new System.Drawing.Size(53, 12);
            this.lblMPhone.TabIndex = 14;
            this.lblMPhone.Text = "移动电话";
            // 
            // lblPhone
            // 
            this.lblPhone.Location = new System.Drawing.Point(7, 102);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPhone.Size = new System.Drawing.Size(53, 12);
            this.lblPhone.TabIndex = 12;
            this.lblPhone.Text = "电话";
            // 
            // tbNo2
            // 
            this.tbNo2.Location = new System.Drawing.Point(235, 75);
            this.tbNo2.Name = "tbNo2";
            this.tbNo2.Size = new System.Drawing.Size(100, 21);
            this.tbNo2.TabIndex = 11;
            // 
            // lvlNo2
            // 
            this.lvlNo2.Location = new System.Drawing.Point(176, 78);
            this.lvlNo2.Name = "lvlNo2";
            this.lvlNo2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lvlNo2.Size = new System.Drawing.Size(53, 12);
            this.lvlNo2.TabIndex = 10;
            this.lvlNo2.Text = "合约编号";
            // 
            // tbnational
            // 
            this.tbnational.Location = new System.Drawing.Point(66, 72);
            this.tbnational.Name = "tbnational";
            this.tbnational.Size = new System.Drawing.Size(100, 21);
            this.tbnational.TabIndex = 9;
            this.tbnational.Text = "汉族";
            // 
            // lblNational
            // 
            this.lblNational.Location = new System.Drawing.Point(7, 75);
            this.lblNational.Name = "lblNational";
            this.lblNational.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblNational.Size = new System.Drawing.Size(53, 12);
            this.lblNational.TabIndex = 8;
            this.lblNational.Text = "民族";
            // 
            // tbNationality
            // 
            this.tbNationality.Location = new System.Drawing.Point(235, 45);
            this.tbNationality.Name = "tbNationality";
            this.tbNationality.Size = new System.Drawing.Size(100, 21);
            this.tbNationality.TabIndex = 7;
            this.tbNationality.Text = "中国";
            // 
            // lblNationality
            // 
            this.lblNationality.Location = new System.Drawing.Point(176, 48);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblNationality.Size = new System.Drawing.Size(53, 12);
            this.lblNationality.TabIndex = 6;
            this.lblNationality.Text = "国籍";
            // 
            // lblSex
            // 
            this.lblSex.Location = new System.Drawing.Point(7, 48);
            this.lblSex.Name = "lblSex";
            this.lblSex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblSex.Size = new System.Drawing.Size(53, 12);
            this.lblSex.TabIndex = 4;
            this.lblSex.Text = "性别";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(235, 18);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(100, 21);
            this.tbName.TabIndex = 3;
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(176, 21);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(53, 12);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "姓名";
            // 
            // lblNo
            // 
            this.lblNo.Location = new System.Drawing.Point(7, 21);
            this.lblNo.Name = "lblNo";
            this.lblNo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblNo.Size = new System.Drawing.Size(53, 12);
            this.lblNo.TabIndex = 0;
            this.lblNo.Text = "卡号";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(410, 333);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "录入(&A)";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(491, 333);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "取消(&Q)";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmAddNewVip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 362);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddNewVip";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "新会员登记";
            this.Activated += new System.EventHandler(this.frmAddNewVip_Activated);
            this.Deactivate += new System.EventHandler(this.frmAddNewVip_Deactivate);
            this.Load += new System.EventHandler(this.frmAddNewVip_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTempTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRemain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowMach)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNo;
        private System.Windows.Forms.TextBox tbTips;
        private System.Windows.Forms.Label lblTips;
        private System.Windows.Forms.Button btnShoot;
        private System.Windows.Forms.Button btnOpenVideo;
        private System.Windows.Forms.Panel pVideo;
        private System.Windows.Forms.Label lblRemain;
        private System.Windows.Forms.Label lvlHowMach;
        private System.Windows.Forms.Label lblCardKind;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.Label lblBgnTime;
        private System.Windows.Forms.Label lblMPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox tbNo2;
        private System.Windows.Forms.Label lvlNo2;
        private System.Windows.Forms.TextBox tbnational;
        private System.Windows.Forms.Label lblNational;
        private System.Windows.Forms.TextBox tbNationality;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbSex;
        private UI.VideoWork vw;
        private System.Windows.Forms.ComboBox cbCardKind;
        private System.Windows.Forms.DateTimePicker dataEnd;
        private System.Windows.Forms.DateTimePicker dataBgn;
        private System.Windows.Forms.NumericUpDown numRemain;
        private System.Windows.Forms.NumericUpDown numHowMach;
        private System.Windows.Forms.NumericUpDown numTempTimes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTelephone;
        private System.Windows.Forms.TextBox tbCardNo;
        private System.Windows.Forms.TextBox tbMobilephone;
    }
}