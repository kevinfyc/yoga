﻿namespace UI
{
    partial class frmRfTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbResult = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnValueOp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnWriteData = new System.Windows.Forms.Button();
            this.btnReadData = new System.Windows.Forms.Button();
            this.btnAuth = new System.Windows.Forms.Button();
            this.textData = new System.Windows.Forms.TextBox();
            this.textValue = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textSec = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textKey = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSeekCard = new System.Windows.Forms.Button();
            this.lbSnr = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBeep = new System.Windows.Forms.Button();
            this.lbSoftVer = new System.Windows.Forms.Label();
            this.lbHardVer = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lbBaud = new System.Windows.Forms.Label();
            this.lbPort = new System.Windows.Forms.Label();
            this.comboBaud = new System.Windows.Forms.ComboBox();
            this.comboPort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbResult
            // 
            this.lbResult.Location = new System.Drawing.Point(106, 428);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(288, 23);
            this.lbResult.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(18, 428);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 23);
            this.label3.TabIndex = 26;
            this.label3.Text = "状态提示：";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnValueOp
            // 
            this.btnValueOp.Location = new System.Drawing.Point(304, 160);
            this.btnValueOp.Name = "btnValueOp";
            this.btnValueOp.Size = new System.Drawing.Size(75, 23);
            this.btnValueOp.TabIndex = 14;
            this.btnValueOp.Text = "值操作";
            this.btnValueOp.Click += new System.EventHandler(this.btnValueOp_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnValueOp);
            this.groupBox2.Controls.Add(this.btnWriteData);
            this.groupBox2.Controls.Add(this.btnReadData);
            this.groupBox2.Controls.Add(this.btnAuth);
            this.groupBox2.Controls.Add(this.textData);
            this.groupBox2.Controls.Add(this.textValue);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textSec);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textKey);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnSeekCard);
            this.groupBox2.Controls.Add(this.lbSnr);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(18, 204);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(408, 208);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "mifareone卡操作";
            // 
            // btnWriteData
            // 
            this.btnWriteData.Location = new System.Drawing.Point(304, 128);
            this.btnWriteData.Name = "btnWriteData";
            this.btnWriteData.Size = new System.Drawing.Size(75, 23);
            this.btnWriteData.TabIndex = 13;
            this.btnWriteData.Text = "写数据";
            this.btnWriteData.Click += new System.EventHandler(this.btnWriteData_Click);
            // 
            // btnReadData
            // 
            this.btnReadData.Location = new System.Drawing.Point(304, 96);
            this.btnReadData.Name = "btnReadData";
            this.btnReadData.Size = new System.Drawing.Size(75, 23);
            this.btnReadData.TabIndex = 12;
            this.btnReadData.Text = "读数据";
            this.btnReadData.Click += new System.EventHandler(this.btnReadData_Click);
            // 
            // btnAuth
            // 
            this.btnAuth.Location = new System.Drawing.Point(304, 64);
            this.btnAuth.Name = "btnAuth";
            this.btnAuth.Size = new System.Drawing.Size(75, 23);
            this.btnAuth.TabIndex = 11;
            this.btnAuth.Text = "认证";
            this.btnAuth.Click += new System.EventHandler(this.btnAuth_Click);
            // 
            // textData
            // 
            this.textData.Location = new System.Drawing.Point(96, 128);
            this.textData.Name = "textData";
            this.textData.Size = new System.Drawing.Size(200, 21);
            this.textData.TabIndex = 10;
            // 
            // textValue
            // 
            this.textValue.Location = new System.Drawing.Point(96, 160);
            this.textValue.Name = "textValue";
            this.textValue.Size = new System.Drawing.Size(136, 21);
            this.textValue.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(16, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 23);
            this.label8.TabIndex = 8;
            this.label8.Text = "值";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textSec
            // 
            this.textSec.Location = new System.Drawing.Point(96, 64);
            this.textSec.Name = "textSec";
            this.textSec.Size = new System.Drawing.Size(136, 21);
            this.textSec.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(16, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "扇区号";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 128);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "数据";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textKey
            // 
            this.textKey.Location = new System.Drawing.Point(96, 96);
            this.textKey.Name = "textKey";
            this.textKey.Size = new System.Drawing.Size(136, 21);
            this.textKey.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(16, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 23);
            this.label5.TabIndex = 3;
            this.label5.Text = "密码";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSeekCard
            // 
            this.btnSeekCard.Location = new System.Drawing.Point(304, 32);
            this.btnSeekCard.Name = "btnSeekCard";
            this.btnSeekCard.Size = new System.Drawing.Size(75, 23);
            this.btnSeekCard.TabIndex = 2;
            this.btnSeekCard.Text = "寻卡";
            this.btnSeekCard.Click += new System.EventHandler(this.btnSeekCard_Click);
            // 
            // lbSnr
            // 
            this.lbSnr.Location = new System.Drawing.Point(104, 32);
            this.lbSnr.Name = "lbSnr";
            this.lbSnr.Size = new System.Drawing.Size(121, 20);
            this.lbSnr.TabIndex = 1;
            this.lbSnr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "卡片序列号";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnBeep
            // 
            this.btnBeep.Location = new System.Drawing.Point(304, 104);
            this.btnBeep.Name = "btnBeep";
            this.btnBeep.Size = new System.Drawing.Size(75, 23);
            this.btnBeep.TabIndex = 0;
            this.btnBeep.Text = "蜂鸣";
            this.btnBeep.Click += new System.EventHandler(this.btnBeep_Click);
            // 
            // lbSoftVer
            // 
            this.lbSoftVer.Location = new System.Drawing.Point(130, 148);
            this.lbSoftVer.Name = "lbSoftVer";
            this.lbSoftVer.Size = new System.Drawing.Size(121, 20);
            this.lbSoftVer.TabIndex = 23;
            this.lbSoftVer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbHardVer
            // 
            this.lbHardVer.Location = new System.Drawing.Point(130, 116);
            this.lbHardVer.Name = "lbHardVer";
            this.lbHardVer.Size = new System.Drawing.Size(121, 20);
            this.lbHardVer.TabIndex = 22;
            this.lbHardVer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBeep);
            this.groupBox1.Location = new System.Drawing.Point(18, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(408, 176);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "初始化串口";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(34, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "接口版本号";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(322, 36);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 14;
            this.btnConnect.Text = "连接";
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lbBaud
            // 
            this.lbBaud.Location = new System.Drawing.Point(34, 76);
            this.lbBaud.Name = "lbBaud";
            this.lbBaud.Size = new System.Drawing.Size(72, 20);
            this.lbBaud.TabIndex = 19;
            this.lbBaud.Text = "波特率";
            this.lbBaud.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbPort
            // 
            this.lbPort.Location = new System.Drawing.Point(34, 36);
            this.lbPort.Name = "lbPort";
            this.lbPort.Size = new System.Drawing.Size(72, 20);
            this.lbPort.TabIndex = 18;
            this.lbPort.Text = "端口";
            this.lbPort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBaud
            // 
            this.comboBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBaud.Location = new System.Drawing.Point(130, 76);
            this.comboBaud.Name = "comboBaud";
            this.comboBaud.Size = new System.Drawing.Size(121, 20);
            this.comboBaud.TabIndex = 17;
            // 
            // comboPort
            // 
            this.comboPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPort.Location = new System.Drawing.Point(130, 36);
            this.comboPort.Name = "comboPort";
            this.comboPort.Size = new System.Drawing.Size(121, 20);
            this.comboPort.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(34, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "硬件版本号";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(322, 76);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(75, 23);
            this.btnDisconnect.TabIndex = 15;
            this.btnDisconnect.Text = "断开连接";
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // frmRfTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 462);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lbSoftVer);
            this.Controls.Add(this.lbHardVer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lbBaud);
            this.Controls.Add(this.lbPort);
            this.Controls.Add(this.comboBaud);
            this.Controls.Add(this.comboPort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmRfTest";
            this.Text = "frmRfTest";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnValueOp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnWriteData;
        private System.Windows.Forms.Button btnReadData;
        private System.Windows.Forms.Button btnAuth;
        private System.Windows.Forms.TextBox textData;
        private System.Windows.Forms.TextBox textValue;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textSec;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textKey;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSeekCard;
        private System.Windows.Forms.Label lbSnr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnBeep;
        private System.Windows.Forms.Label lbSoftVer;
        private System.Windows.Forms.Label lbHardVer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lbBaud;
        private System.Windows.Forms.Label lbPort;
        private System.Windows.Forms.ComboBox comboBaud;
        private System.Windows.Forms.ComboBox comboPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDisconnect;


    }
}