﻿namespace UI.Coach
{
    partial class frmCoachAllot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataCoachInfo = new System.Windows.Forms.DataGridView();
            this.clId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clIsPrivate = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataMemberInfo = new System.Windows.Forms.DataGridView();
            this.clMemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMenName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clCoachId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clCardType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAllot = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCoachInfo)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataMemberInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataCoachInfo);
            this.groupBox1.Location = new System.Drawing.Point(14, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(369, 510);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "教练顾问信息";
            // 
            // dataCoachInfo
            // 
            this.dataCoachInfo.AllowUserToAddRows = false;
            this.dataCoachInfo.AllowUserToDeleteRows = false;
            this.dataCoachInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCoachInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clId,
            this.clName,
            this.clIsPrivate});
            this.dataCoachInfo.Location = new System.Drawing.Point(7, 21);
            this.dataCoachInfo.MultiSelect = false;
            this.dataCoachInfo.Name = "dataCoachInfo";
            this.dataCoachInfo.ReadOnly = true;
            this.dataCoachInfo.RowTemplate.Height = 23;
            this.dataCoachInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataCoachInfo.Size = new System.Drawing.Size(355, 483);
            this.dataCoachInfo.TabIndex = 0;
            // 
            // clId
            // 
            this.clId.DataPropertyName = "Id";
            this.clId.HeaderText = "编号";
            this.clId.Name = "clId";
            this.clId.ReadOnly = true;
            // 
            // clName
            // 
            this.clName.DataPropertyName = "Name";
            this.clName.HeaderText = "名字";
            this.clName.Name = "clName";
            this.clName.ReadOnly = true;
            // 
            // clIsPrivate
            // 
            this.clIsPrivate.DataPropertyName = "IsPrivate";
            this.clIsPrivate.HeaderText = "是否私教";
            this.clIsPrivate.Name = "clIsPrivate";
            this.clIsPrivate.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataMemberInfo);
            this.groupBox2.Location = new System.Drawing.Point(389, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(383, 510);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "学员信息";
            // 
            // dataMemberInfo
            // 
            this.dataMemberInfo.AllowUserToAddRows = false;
            this.dataMemberInfo.AllowUserToDeleteRows = false;
            this.dataMemberInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataMemberInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clMemId,
            this.clMenName,
            this.clCoachId,
            this.clCardType});
            this.dataMemberInfo.Location = new System.Drawing.Point(6, 20);
            this.dataMemberInfo.Name = "dataMemberInfo";
            this.dataMemberInfo.ReadOnly = true;
            this.dataMemberInfo.RowTemplate.Height = 23;
            this.dataMemberInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataMemberInfo.Size = new System.Drawing.Size(371, 484);
            this.dataMemberInfo.TabIndex = 1;
            // 
            // clMemId
            // 
            this.clMemId.DataPropertyName = "Id";
            this.clMemId.HeaderText = "编号";
            this.clMemId.Name = "clMemId";
            this.clMemId.ReadOnly = true;
            // 
            // clMenName
            // 
            this.clMenName.DataPropertyName = "Name";
            this.clMenName.HeaderText = "姓名";
            this.clMenName.Name = "clMenName";
            this.clMenName.ReadOnly = true;
            // 
            // clCoachId
            // 
            this.clCoachId.DataPropertyName = "CoachId";
            this.clCoachId.HeaderText = "教练编号";
            this.clCoachId.Name = "clCoachId";
            this.clCoachId.ReadOnly = true;
            this.clCoachId.Visible = false;
            // 
            // clCardType
            // 
            this.clCardType.DataPropertyName = "CardType";
            this.clCardType.HeaderText = "卡类型";
            this.clCardType.Name = "clCardType";
            this.clCardType.ReadOnly = true;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new System.Drawing.Point(395, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(63, 22);
            this.btnCancel.TabIndex = 56;
            this.btnCancel.Text = "退出(&X)";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAllot
            // 
            this.btnAllot.AutoSize = true;
            this.btnAllot.Location = new System.Drawing.Point(320, 12);
            this.btnAllot.Name = "btnAllot";
            this.btnAllot.Size = new System.Drawing.Size(63, 22);
            this.btnAllot.TabIndex = 55;
            this.btnAllot.Text = "分配(&S)";
            this.btnAllot.UseVisualStyleBackColor = true;
            this.btnAllot.Click += new System.EventHandler(this.btnAllot_Click);
            // 
            // frmCoachAllot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAllot);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCoachAllot";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "教练分配";
            this.Activated += new System.EventHandler(this.frmCoachAllot_Activated);
            this.Deactivate += new System.EventHandler(this.frmCoachAllot_Deactivate);
            this.Load += new System.EventHandler(this.frmCoachAllot_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataCoachInfo)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataMemberInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataCoachInfo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataMemberInfo;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAllot;
        private System.Windows.Forms.DataGridViewTextBoxColumn clId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clIsPrivate;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMemId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMenName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCoachId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCardType;
    }
}