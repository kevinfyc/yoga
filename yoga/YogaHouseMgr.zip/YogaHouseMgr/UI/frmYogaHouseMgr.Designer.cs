﻿namespace UI
{
    partial class frmYogaHouseMgr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYogaHouseMgr));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.前台FToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.会员资料管理MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.积分查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.积分获取GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.积分消费SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.柜子管理RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.会员进场EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.会员进场管理OToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键清场JToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教练CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教练分配AToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.教练管理MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.会籍JToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.转正GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.管理MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.跟踪TToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.顾问管理AToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.收款单CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.付款单PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.收款单管理MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.付款单管理TToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.其他OToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品管理GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加会员AToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.账户管理UToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tssl = new System.Windows.Forms.ToolStripStatusLabel();
            this.curActiveFrm = new System.Windows.Forms.ToolStripStatusLabel();
            this.statueUserType = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.前台FToolStripMenuItem,
            this.教练CToolStripMenuItem,
            this.会籍JToolStripMenuItem,
            this.toolStripMenuItem4,
            this.其他OToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 前台FToolStripMenuItem
            // 
            this.前台FToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.会员资料管理MToolStripMenuItem,
            this.toolStripMenuItem7,
            this.toolStripMenuItem9,
            this.toolStripMenuItem12,
            this.toolStripMenuItem8,
            this.toolStripMenuItem13,
            this.toolStripMenuItem6,
            this.积分查询ToolStripMenuItem,
            this.积分获取GToolStripMenuItem,
            this.积分消费SToolStripMenuItem,
            this.toolStripMenuItem10,
            this.柜子管理RToolStripMenuItem,
            this.toolStripSeparator1,
            this.会员进场EToolStripMenuItem,
            this.会员进场管理OToolStripMenuItem,
            this.一键清场JToolStripMenuItem});
            this.前台FToolStripMenuItem.Name = "前台FToolStripMenuItem";
            this.前台FToolStripMenuItem.Size = new System.Drawing.Size(58, 21);
            this.前台FToolStripMenuItem.Text = "前台(&F)";
            // 
            // 会员资料管理MToolStripMenuItem
            // 
            this.会员资料管理MToolStripMenuItem.Name = "会员资料管理MToolStripMenuItem";
            this.会员资料管理MToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.会员资料管理MToolStripMenuItem.Text = "会员资料管理(&M)";
            this.会员资料管理MToolStripMenuItem.Click += new System.EventHandler(this.会员资料管理MToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem7.Text = "会员查询(&Q)";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem9.Text = "会员充值(&P)";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem12.Text = "会员充值管理(&O)";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem8.Text = "会员扣值(&C)";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem13.Text = "会员扣值管理(&D)";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(165, 6);
            // 
            // 积分查询ToolStripMenuItem
            // 
            this.积分查询ToolStripMenuItem.Name = "积分查询ToolStripMenuItem";
            this.积分查询ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.积分查询ToolStripMenuItem.Text = "积分查询(&I)";
            this.积分查询ToolStripMenuItem.Click += new System.EventHandler(this.积分查询ToolStripMenuItem_Click);
            // 
            // 积分获取GToolStripMenuItem
            // 
            this.积分获取GToolStripMenuItem.Name = "积分获取GToolStripMenuItem";
            this.积分获取GToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.积分获取GToolStripMenuItem.Text = "积分获取(&G)";
            this.积分获取GToolStripMenuItem.Click += new System.EventHandler(this.积分获取GToolStripMenuItem_Click);
            // 
            // 积分消费SToolStripMenuItem
            // 
            this.积分消费SToolStripMenuItem.Name = "积分消费SToolStripMenuItem";
            this.积分消费SToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.积分消费SToolStripMenuItem.Text = "积分消费(&S)";
            this.积分消费SToolStripMenuItem.Click += new System.EventHandler(this.积分消费SToolStripMenuItem_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(165, 6);
            // 
            // 柜子管理RToolStripMenuItem
            // 
            this.柜子管理RToolStripMenuItem.Name = "柜子管理RToolStripMenuItem";
            this.柜子管理RToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.柜子管理RToolStripMenuItem.Text = "柜子管理(&R)";
            this.柜子管理RToolStripMenuItem.Click += new System.EventHandler(this.柜子管理RToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(165, 6);
            // 
            // 会员进场EToolStripMenuItem
            // 
            this.会员进场EToolStripMenuItem.Name = "会员进场EToolStripMenuItem";
            this.会员进场EToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.会员进场EToolStripMenuItem.Text = "会员进场(&E)";
            this.会员进场EToolStripMenuItem.Click += new System.EventHandler(this.会员进场EToolStripMenuItem_Click);
            // 
            // 会员进场管理OToolStripMenuItem
            // 
            this.会员进场管理OToolStripMenuItem.Name = "会员进场管理OToolStripMenuItem";
            this.会员进场管理OToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.会员进场管理OToolStripMenuItem.Text = "会员进场管理(&O)";
            this.会员进场管理OToolStripMenuItem.Click += new System.EventHandler(this.会员进场管理OToolStripMenuItem_Click);
            // 
            // 一键清场JToolStripMenuItem
            // 
            this.一键清场JToolStripMenuItem.Name = "一键清场JToolStripMenuItem";
            this.一键清场JToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.一键清场JToolStripMenuItem.Text = "一键清场(&J)";
            this.一键清场JToolStripMenuItem.Click += new System.EventHandler(this.一键清场JToolStripMenuItem_Click);
            // 
            // 教练CToolStripMenuItem
            // 
            this.教练CToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.教练分配AToolStripMenuItem,
            this.toolStripMenuItem1,
            this.教练管理MToolStripMenuItem});
            this.教练CToolStripMenuItem.Name = "教练CToolStripMenuItem";
            this.教练CToolStripMenuItem.Size = new System.Drawing.Size(60, 21);
            this.教练CToolStripMenuItem.Text = "教练(&C)";
            // 
            // 教练分配AToolStripMenuItem
            // 
            this.教练分配AToolStripMenuItem.Name = "教练分配AToolStripMenuItem";
            this.教练分配AToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.教练分配AToolStripMenuItem.Text = "教练分配(&A)";
            this.教练分配AToolStripMenuItem.Click += new System.EventHandler(this.教练分配AToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(141, 6);
            // 
            // 教练管理MToolStripMenuItem
            // 
            this.教练管理MToolStripMenuItem.Name = "教练管理MToolStripMenuItem";
            this.教练管理MToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.教练管理MToolStripMenuItem.Text = "教练管理(&M)";
            this.教练管理MToolStripMenuItem.Click += new System.EventHandler(this.教练管理MToolStripMenuItem_Click);
            // 
            // 会籍JToolStripMenuItem
            // 
            this.会籍JToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.转正GToolStripMenuItem,
            this.管理MToolStripMenuItem,
            this.跟踪TToolStripMenuItem,
            this.toolStripMenuItem11,
            this.顾问管理AToolStripMenuItem});
            this.会籍JToolStripMenuItem.Name = "会籍JToolStripMenuItem";
            this.会籍JToolStripMenuItem.Size = new System.Drawing.Size(57, 21);
            this.会籍JToolStripMenuItem.Text = "会籍(&J)";
            // 
            // 转正GToolStripMenuItem
            // 
            this.转正GToolStripMenuItem.Name = "转正GToolStripMenuItem";
            this.转正GToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.转正GToolStripMenuItem.Text = "转正(&G)";
            this.转正GToolStripMenuItem.Click += new System.EventHandler(this.转正GToolStripMenuItem_Click);
            // 
            // 管理MToolStripMenuItem
            // 
            this.管理MToolStripMenuItem.Name = "管理MToolStripMenuItem";
            this.管理MToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.管理MToolStripMenuItem.Text = "管理(&M)";
            this.管理MToolStripMenuItem.Click += new System.EventHandler(this.管理MToolStripMenuItem_Click);
            // 
            // 跟踪TToolStripMenuItem
            // 
            this.跟踪TToolStripMenuItem.Name = "跟踪TToolStripMenuItem";
            this.跟踪TToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.跟踪TToolStripMenuItem.Text = "跟踪(&T)";
            this.跟踪TToolStripMenuItem.Click += new System.EventHandler(this.跟踪TToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(140, 22);
            this.toolStripMenuItem11.Text = "筛选(&P)";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // 顾问管理AToolStripMenuItem
            // 
            this.顾问管理AToolStripMenuItem.Name = "顾问管理AToolStripMenuItem";
            this.顾问管理AToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.顾问管理AToolStripMenuItem.Text = "顾问管理(&A)";
            this.顾问管理AToolStripMenuItem.Click += new System.EventHandler(this.顾问管理AToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.收款单CToolStripMenuItem,
            this.付款单PToolStripMenuItem,
            this.toolStripMenuItem5,
            this.收款单管理MToolStripMenuItem,
            this.付款单管理TToolStripMenuItem});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(64, 21);
            this.toolStripMenuItem4.Text = "财会(&M)";
            // 
            // 收款单CToolStripMenuItem
            // 
            this.收款单CToolStripMenuItem.Name = "收款单CToolStripMenuItem";
            this.收款单CToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.收款单CToolStripMenuItem.Text = "收款单(&C)";
            this.收款单CToolStripMenuItem.Click += new System.EventHandler(this.收款单CToolStripMenuItem_Click);
            // 
            // 付款单PToolStripMenuItem
            // 
            this.付款单PToolStripMenuItem.Name = "付款单PToolStripMenuItem";
            this.付款单PToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.付款单PToolStripMenuItem.Text = "付款单(&P)";
            this.付款单PToolStripMenuItem.Click += new System.EventHandler(this.付款单PToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(153, 6);
            // 
            // 收款单管理MToolStripMenuItem
            // 
            this.收款单管理MToolStripMenuItem.Name = "收款单管理MToolStripMenuItem";
            this.收款单管理MToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.收款单管理MToolStripMenuItem.Text = "收款单管理(&M)";
            this.收款单管理MToolStripMenuItem.Click += new System.EventHandler(this.收款单管理MToolStripMenuItem_Click);
            // 
            // 付款单管理TToolStripMenuItem
            // 
            this.付款单管理TToolStripMenuItem.Name = "付款单管理TToolStripMenuItem";
            this.付款单管理TToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.付款单管理TToolStripMenuItem.Text = "付款单管理(&T)";
            this.付款单管理TToolStripMenuItem.Click += new System.EventHandler(this.付款单管理TToolStripMenuItem_Click);
            // 
            // 其他OToolStripMenuItem
            // 
            this.其他OToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.商品管理GToolStripMenuItem,
            this.添加会员AToolStripMenuItem,
            this.账户管理UToolStripMenuItem});
            this.其他OToolStripMenuItem.Name = "其他OToolStripMenuItem";
            this.其他OToolStripMenuItem.Size = new System.Drawing.Size(62, 21);
            this.其他OToolStripMenuItem.Text = "其他(&O)";
            // 
            // 商品管理GToolStripMenuItem
            // 
            this.商品管理GToolStripMenuItem.Name = "商品管理GToolStripMenuItem";
            this.商品管理GToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.商品管理GToolStripMenuItem.Text = "商品管理(&G)";
            this.商品管理GToolStripMenuItem.Click += new System.EventHandler(this.商品管理GToolStripMenuItem_Click);
            // 
            // 添加会员AToolStripMenuItem
            // 
            this.添加会员AToolStripMenuItem.Name = "添加会员AToolStripMenuItem";
            this.添加会员AToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.添加会员AToolStripMenuItem.Text = "添加会员(&A)";
            this.添加会员AToolStripMenuItem.Click += new System.EventHandler(this.添加会员AToolStripMenuItem_Click);
            // 
            // 账户管理UToolStripMenuItem
            // 
            this.账户管理UToolStripMenuItem.Name = "账户管理UToolStripMenuItem";
            this.账户管理UToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.账户管理UToolStripMenuItem.Text = "账户管理(&U)";
            this.账户管理UToolStripMenuItem.Click += new System.EventHandler(this.账户管理UToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssl,
            this.curActiveFrm,
            this.statueUserType});
            this.statusStrip1.Location = new System.Drawing.Point(0, 708);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tssl
            // 
            this.tssl.Name = "tssl";
            this.tssl.Size = new System.Drawing.Size(0, 17);
            // 
            // curActiveFrm
            // 
            this.curActiveFrm.Name = "curActiveFrm";
            this.curActiveFrm.Size = new System.Drawing.Size(0, 17);
            // 
            // statueUserType
            // 
            this.statueUserType.Name = "statueUserType";
            this.statueUserType.Size = new System.Drawing.Size(0, 17);
            // 
            // frmYogaHouseMgr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::UI.Properties.Resources.backimage;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmYogaHouseMgr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "北京天悦瑜伽馆管理系统";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmYogaHouseMgr_Load);
            this.ResizeBegin += new System.EventHandler(this.frmYogaHouseMgr_ResizeBegin);
            this.ResizeEnd += new System.EventHandler(this.frmYogaHouseMgr_ResizeEnd);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 前台FToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教练CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教练分配AToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 教练管理MToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 会籍JToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 转正GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 管理MToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 其他OToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品管理GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 跟踪TToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem 收款单CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 付款单PToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem 收款单管理MToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 付款单管理TToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 会员资料管理MToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem 积分查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem 积分获取GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 积分消费SToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem 柜子管理RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 会员进场EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 会员进场管理OToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加会员AToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 账户管理UToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tssl;
        private System.Windows.Forms.ToolStripStatusLabel curActiveFrm;
        private System.Windows.Forms.ToolStripStatusLabel statueUserType;
        private System.Windows.Forms.ToolStripMenuItem 顾问管理AToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一键清场JToolStripMenuItem;
    }
}