﻿namespace UI.Potential
{
    partial class frmPotentialCustomersToVip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.paging1 = new Control.Paging();
            this.dataVipInfo = new System.Windows.Forms.DataGridView();
            this.clCardNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMobilephone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAdviser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clCreateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clLastContact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clCustomerChannel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbAdviser = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbCardNo = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNo = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataVipInfo)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new System.Drawing.Point(690, 20);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(63, 22);
            this.btnCancel.TabIndex = 65;
            this.btnCancel.Text = "退出(&X)";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.AutoSize = true;
            this.btnQuery.Location = new System.Drawing.Point(555, 20);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(63, 22);
            this.btnQuery.TabIndex = 64;
            this.btnQuery.Text = "查询(&Q)";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnChange
            // 
            this.btnChange.AutoSize = true;
            this.btnChange.Location = new System.Drawing.Point(624, 19);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(60, 22);
            this.btnChange.TabIndex = 63;
            this.btnChange.Text = "转正(&T)";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.paging1);
            this.groupBox1.Controls.Add(this.dataVipInfo);
            this.groupBox1.Location = new System.Drawing.Point(13, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 485);
            this.groupBox1.TabIndex = 72;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "潜在客户信息";
            // 
            // paging1
            // 
            this.paging1.CurrentPage = 0;
            this.paging1.Location = new System.Drawing.Point(6, 20);
            this.paging1.Name = "paging1";
            this.paging1.Size = new System.Drawing.Size(760, 22);
            this.paging1.TabIndex = 91;
            // 
            // dataVipInfo
            // 
            this.dataVipInfo.AllowUserToAddRows = false;
            this.dataVipInfo.AllowUserToDeleteRows = false;
            this.dataVipInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataVipInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clCardNo,
            this.clName,
            this.clGender,
            this.clMobilephone,
            this.clAdviser,
            this.clCreateTime,
            this.clLastContact,
            this.clCustomerChannel,
            this.clRemarks});
            this.dataVipInfo.Location = new System.Drawing.Point(6, 48);
            this.dataVipInfo.Name = "dataVipInfo";
            this.dataVipInfo.ReadOnly = true;
            this.dataVipInfo.RowTemplate.Height = 23;
            this.dataVipInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataVipInfo.Size = new System.Drawing.Size(760, 431);
            this.dataVipInfo.TabIndex = 92;
            // 
            // clCardNo
            // 
            this.clCardNo.DataPropertyName = "Id";
            this.clCardNo.HeaderText = "编号";
            this.clCardNo.Name = "clCardNo";
            this.clCardNo.ReadOnly = true;
            // 
            // clName
            // 
            this.clName.DataPropertyName = "Name";
            this.clName.HeaderText = "姓名";
            this.clName.Name = "clName";
            this.clName.ReadOnly = true;
            this.clName.Width = 80;
            // 
            // clGender
            // 
            this.clGender.DataPropertyName = "Gender";
            this.clGender.HeaderText = "性别";
            this.clGender.Name = "clGender";
            this.clGender.ReadOnly = true;
            this.clGender.Width = 52;
            // 
            // clMobilephone
            // 
            this.clMobilephone.DataPropertyName = "Mobilephone";
            this.clMobilephone.HeaderText = "手机号码";
            this.clMobilephone.Name = "clMobilephone";
            this.clMobilephone.ReadOnly = true;
            this.clMobilephone.Width = 80;
            // 
            // clAdviser
            // 
            this.clAdviser.DataPropertyName = "AdviserId";
            this.clAdviser.HeaderText = "顾问";
            this.clAdviser.Name = "clAdviser";
            this.clAdviser.ReadOnly = true;
            this.clAdviser.Width = 60;
            // 
            // clCreateTime
            // 
            this.clCreateTime.DataPropertyName = "CreateTime";
            this.clCreateTime.HeaderText = "加入时间";
            this.clCreateTime.Name = "clCreateTime";
            this.clCreateTime.ReadOnly = true;
            this.clCreateTime.Width = 90;
            // 
            // clLastContact
            // 
            this.clLastContact.DataPropertyName = "LastContact";
            this.clLastContact.HeaderText = "最近联系";
            this.clLastContact.Name = "clLastContact";
            this.clLastContact.ReadOnly = true;
            this.clLastContact.Width = 90;
            // 
            // clCustomerChannel
            // 
            this.clCustomerChannel.DataPropertyName = "CustomerChannel";
            this.clCustomerChannel.HeaderText = "客户渠道";
            this.clCustomerChannel.Name = "clCustomerChannel";
            this.clCustomerChannel.ReadOnly = true;
            // 
            // clRemarks
            // 
            this.clRemarks.DataPropertyName = "Remarks";
            this.clRemarks.HeaderText = "备注";
            this.clRemarks.Name = "clRemarks";
            this.clRemarks.ReadOnly = true;
            // 
            // cbAdviser
            // 
            this.cbAdviser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAdviser.FormattingEnabled = true;
            this.cbAdviser.Location = new System.Drawing.Point(281, 20);
            this.cbAdviser.Name = "cbAdviser";
            this.cbAdviser.Size = new System.Drawing.Size(77, 20);
            this.cbAdviser.TabIndex = 102;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(238, 26);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(37, 12);
            this.label1.TabIndex = 101;
            this.label1.Text = "顾问";
            // 
            // tbCardNo
            // 
            this.tbCardNo.Location = new System.Drawing.Point(50, 20);
            this.tbCardNo.Name = "tbCardNo";
            this.tbCardNo.Size = new System.Drawing.Size(79, 21);
            this.tbCardNo.TabIndex = 100;
            this.tbCardNo.Text = "0";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(180, 20);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(52, 21);
            this.tbName.TabIndex = 99;
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(133, 26);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(41, 12);
            this.lblName.TabIndex = 98;
            this.lblName.Text = "姓名";
            // 
            // lblNo
            // 
            this.lblNo.Location = new System.Drawing.Point(12, 26);
            this.lblNo.Name = "lblNo";
            this.lblNo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblNo.Size = new System.Drawing.Size(32, 12);
            this.lblNo.TabIndex = 97;
            this.lblNo.Text = "编号";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbAdviser);
            this.groupBox2.Controls.Add(this.tbCardNo);
            this.groupBox2.Controls.Add(this.btnCancel);
            this.groupBox2.Controls.Add(this.lblNo);
            this.groupBox2.Controls.Add(this.btnQuery);
            this.groupBox2.Controls.Add(this.btnChange);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblName);
            this.groupBox2.Controls.Add(this.tbName);
            this.groupBox2.Location = new System.Drawing.Point(13, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(759, 50);
            this.groupBox2.TabIndex = 103;
            this.groupBox2.TabStop = false;
            // 
            // frmPotentialCustomersToVip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPotentialCustomersToVip";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "潜在客户转正信息";
            this.Activated += new System.EventHandler(this.frmPotentialCustomersToVip_Activated);
            this.Deactivate += new System.EventHandler(this.frmPotentialCustomersToVip_Deactivate);
            this.Load += new System.EventHandler(this.frmPotentialCustomersToVip_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataVipInfo)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataVipInfo;
        private Control.Paging paging1;
        private System.Windows.Forms.ComboBox cbAdviser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbCardNo;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblNo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCardNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clGender;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMobilephone;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAdviser;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCreateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn clLastContact;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCustomerChannel;
        private System.Windows.Forms.DataGridViewTextBoxColumn clRemarks;
    }
}