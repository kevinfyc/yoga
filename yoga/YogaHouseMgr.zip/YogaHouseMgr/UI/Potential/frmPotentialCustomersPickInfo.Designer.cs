﻿namespace UI.Potential
{
    partial class frmPotentialCustomersPickInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvPublic = new System.Windows.Forms.DataGridView();
            this.clCardNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCoachNo = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvCurrent = new System.Windows.Forms.DataGridView();
            this.clId2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clLastTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMobilePhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbAdviserId = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPublic)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCurrent)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvPublic);
            this.groupBox2.Location = new System.Drawing.Point(389, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(383, 510);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "公共区域潜在客户";
            // 
            // dgvPublic
            // 
            this.dgvPublic.AllowUserToAddRows = false;
            this.dgvPublic.AllowUserToDeleteRows = false;
            this.dgvPublic.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPublic.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clCardNo,
            this.clName,
            this.clGender,
            this.dataGridViewTextBoxColumn1});
            this.dgvPublic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPublic.Location = new System.Drawing.Point(3, 17);
            this.dgvPublic.Name = "dgvPublic";
            this.dgvPublic.ReadOnly = true;
            this.dgvPublic.RowTemplate.Height = 23;
            this.dgvPublic.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPublic.Size = new System.Drawing.Size(377, 490);
            this.dgvPublic.TabIndex = 92;
            // 
            // clCardNo
            // 
            this.clCardNo.DataPropertyName = "Id";
            this.clCardNo.HeaderText = "编号";
            this.clCardNo.Name = "clCardNo";
            this.clCardNo.ReadOnly = true;
            // 
            // clName
            // 
            this.clName.DataPropertyName = "Name";
            this.clName.HeaderText = "姓名";
            this.clName.Name = "clName";
            this.clName.ReadOnly = true;
            this.clName.Width = 80;
            // 
            // clGender
            // 
            this.clGender.DataPropertyName = "Gender";
            this.clGender.HeaderText = "性别";
            this.clGender.Name = "clGender";
            this.clGender.ReadOnly = true;
            this.clGender.Width = 52;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Mobilephone";
            this.dataGridViewTextBoxColumn1.HeaderText = "手机号码";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // lblCoachNo
            // 
            this.lblCoachNo.Location = new System.Drawing.Point(110, 15);
            this.lblCoachNo.Name = "lblCoachNo";
            this.lblCoachNo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCoachNo.Size = new System.Drawing.Size(53, 12);
            this.lblCoachNo.TabIndex = 60;
            this.lblCoachNo.Text = "顾问编号";
            this.lblCoachNo.Visible = false;
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(51, 12);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(52, 21);
            this.tbName.TabIndex = 59;
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(4, 15);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(41, 12);
            this.lblName.TabIndex = 58;
            this.lblName.Text = "姓名";
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new System.Drawing.Point(709, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(63, 22);
            this.btnCancel.TabIndex = 56;
            this.btnCancel.Text = "退出(&X)";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.AutoSize = true;
            this.btnQuery.Location = new System.Drawing.Point(272, 11);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(63, 22);
            this.btnQuery.TabIndex = 55;
            this.btnQuery.Text = "查询(&Q)";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSize = true;
            this.btnAdd.Location = new System.Drawing.Point(350, 11);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(60, 22);
            this.btnAdd.TabIndex = 54;
            this.btnAdd.Text = "添加(&A)";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvCurrent);
            this.groupBox1.Location = new System.Drawing.Point(14, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(369, 511);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "当前会籍顾问潜在客户";
            // 
            // dgvCurrent
            // 
            this.dgvCurrent.AllowUserToAddRows = false;
            this.dgvCurrent.AllowUserToDeleteRows = false;
            this.dgvCurrent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCurrent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clId2,
            this.clName2,
            this.clLastTime,
            this.clMobilePhone});
            this.dgvCurrent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCurrent.Location = new System.Drawing.Point(3, 17);
            this.dgvCurrent.Name = "dgvCurrent";
            this.dgvCurrent.ReadOnly = true;
            this.dgvCurrent.RowTemplate.Height = 23;
            this.dgvCurrent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCurrent.Size = new System.Drawing.Size(363, 491);
            this.dgvCurrent.TabIndex = 2;
            // 
            // clId2
            // 
            this.clId2.DataPropertyName = "Id";
            this.clId2.HeaderText = "编号";
            this.clId2.Name = "clId2";
            this.clId2.ReadOnly = true;
            this.clId2.Width = 80;
            // 
            // clName2
            // 
            this.clName2.DataPropertyName = "Name";
            this.clName2.HeaderText = "姓名";
            this.clName2.Name = "clName2";
            this.clName2.ReadOnly = true;
            this.clName2.Width = 85;
            // 
            // clLastTime
            // 
            this.clLastTime.DataPropertyName = "LastContact";
            this.clLastTime.HeaderText = "最后联系";
            this.clLastTime.Name = "clLastTime";
            this.clLastTime.ReadOnly = true;
            // 
            // clMobilePhone
            // 
            this.clMobilePhone.DataPropertyName = "Remarks";
            this.clMobilePhone.HeaderText = "备注";
            this.clMobilePhone.Name = "clMobilePhone";
            this.clMobilePhone.ReadOnly = true;
            this.clMobilePhone.Width = 85;
            // 
            // tbAdviserId
            // 
            this.tbAdviserId.Location = new System.Drawing.Point(169, 12);
            this.tbAdviserId.Name = "tbAdviserId";
            this.tbAdviserId.ReadOnly = true;
            this.tbAdviserId.Size = new System.Drawing.Size(77, 21);
            this.tbAdviserId.TabIndex = 61;
            this.tbAdviserId.Visible = false;
            // 
            // frmPotentialCustomersPickInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.tbAdviserId);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblCoachNo);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPotentialCustomersPickInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "潜在客户筛选";
            this.Activated += new System.EventHandler(this.frmPotentialCustomersPickInfo_Activated);
            this.Deactivate += new System.EventHandler(this.frmPotentialCustomersPickInfo_Deactivate);
            this.Load += new System.EventHandler(this.frmPotentialCustomersPickInfo_Load);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPublic)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCurrent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblCoachNo;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvCurrent;
        private System.Windows.Forms.DataGridViewTextBoxColumn clId2;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName2;
        private System.Windows.Forms.DataGridViewTextBoxColumn clLastTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMobilePhone;
        private System.Windows.Forms.DataGridView dgvPublic;
        private System.Windows.Forms.DataGridViewTextBoxColumn clCardNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clGender;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.TextBox tbAdviserId;
    }
}